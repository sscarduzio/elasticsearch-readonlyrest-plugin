"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReadonlyrestKbnPlugin = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_dom_1 = __importDefault(require("react-dom"));
const rorMenu_1 = require("./components/rorMenu");
const coreFunctions_1 = __importDefault(require("./utils/coreFunctions"));
class ReadonlyrestKbnPlugin {
    initializerContext;
    config;
    constructor(initializerContext) {
        this.initializerContext = initializerContext;
        this.config = this.initializerContext.config.get();
    }
    setup() {
        return {};
    }
    start(core) {
        coreFunctions_1.default.initialization(core);
        core.chrome.navControls.registerRight({
            order: 10000,
            mount: target => this.mount(target)
        });
        return {};
    }
    mount(target) {
        let redirectToLogout = coreFunctions_1.default.serverBasePathPrepend('/logout');
        const origin = this.config.identity['x-ror-origin'];
        if (origin) {
            redirectToLogout += `?x-ror-origin=${origin}`;
        }
        react_dom_1.default.render((0, jsx_runtime_1.jsx)(rorMenu_1.RorMenu, { pkpBasePath: coreFunctions_1.default.serverBasePathPrepend('/pkp'), logoutRedirect: redirectToLogout, clearSessionOnEvents: this.config.clearSessionOnEvents }), target);
        return () => react_dom_1.default.unmountComponentAtNode(target);
    }
}
exports.ReadonlyrestKbnPlugin = ReadonlyrestKbnPlugin;
