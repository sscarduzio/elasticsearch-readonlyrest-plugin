"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const React = tslib_1.__importStar(require("react"));
const react_1 = require("react");
const menu_1 = tslib_1.__importDefault(require("../common/menu"));
const menuButton_1 = tslib_1.__importDefault(require("../common/menuButton"));
function TenancySelect({ currentGroup, availableGroups, handleChange, closeMainMenu }) {
    const [menuOpened, setMenuOpened] = React.useState(false);
    const [searchValue, setSearchValue] = (0, react_1.useState)('');
    const toggleMenu = () => setMenuOpened(prevState => !prevState);
    const handleCloseMenu = () => setMenuOpened(false);
    const items = (0, react_1.useMemo)(() => availableGroups
        .filter(group => group.toLowerCase().includes(searchValue.toLowerCase()))
        .map(group => ({
        title: group,
        action: () => {
            handleChange(group);
        }
    })), [availableGroups, handleChange, searchValue]);
    return ((0, jsx_runtime_1.jsx)(menu_1.default, { button: (0, jsx_runtime_1.jsx)(menuButton_1.default, { text: "Change tenancy", handleClick: toggleMenu, className: "ror_change_tenancy" }), isOpen: menuOpened, items: items, selectedItem: currentGroup, closeMainMenu: closeMainMenu, handleClose: handleCloseMenu, search: availableGroups.length > 5
            ? {
                placeholder: 'Search for tenancy',
                isClearable: true,
                onChange: e => {
                    // @ts-ignore
                    setSearchValue(e.target.value);
                },
                value: searchValue
            }
            : undefined }));
}
exports.default = TenancySelect;
