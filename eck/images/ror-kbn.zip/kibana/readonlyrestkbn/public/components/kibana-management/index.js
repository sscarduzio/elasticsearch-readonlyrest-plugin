"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_1 = require("react");
const semver = tslib_1.__importStar(require("semver"));
const menu_1 = tslib_1.__importDefault(require("../common/menu"));
const coreFunctions_1 = tslib_1.__importDefault(require("../../utils/coreFunctions"));
const menuButton_1 = tslib_1.__importDefault(require("../common/menuButton"));
const menuItems = (kibanaVersion) => {
    const items = [
        {
            title: 'Reporting',
            action: () => {
                coreFunctions_1.default.redirect(coreFunctions_1.default.basePathPrepend('/app/management/insightsAndAlerting/reporting'));
            }
        },
        {
            title: 'Saved Objects',
            action: () => {
                coreFunctions_1.default.redirect(coreFunctions_1.default.basePathPrepend('/app/management/kibana/objects'));
            }
        }
    ];
    if (semver.gte(kibanaVersion, '8.0.0')) {
        items.splice(1, 0, {
            title: 'Data Views',
            action: () => {
                coreFunctions_1.default.redirect(coreFunctions_1.default.basePathPrepend('/app/management/kibana/dataViews'));
            }
        });
    }
    else {
        items.splice(1, 0, {
            title: 'Index Patterns',
            action: () => {
                coreFunctions_1.default.redirect(coreFunctions_1.default.basePathPrepend('/app/management/kibana/indexPatterns'));
            }
        });
    }
    return items;
};
function KibanaManagement({ closeMainMenu, kibanaVersion }) {
    const [menuOpened, setMenuOpened] = (0, react_1.useState)(false);
    const toggleMenu = () => setMenuOpened(prevState => !prevState);
    const handleMenuClose = () => setMenuOpened(false);
    return ((0, jsx_runtime_1.jsx)(menu_1.default, { button: (0, jsx_runtime_1.jsx)(menuButton_1.default, { text: "Manage kibana", className: "ror_kibana_management", handleClick: toggleMenu }), isOpen: menuOpened, closeMainMenu: closeMainMenu, items: menuItems(kibanaVersion), handleClose: handleMenuClose }));
}
exports.default = KibanaManagement;
