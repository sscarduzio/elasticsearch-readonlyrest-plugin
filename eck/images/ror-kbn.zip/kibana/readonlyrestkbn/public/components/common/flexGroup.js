"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FlexGroup = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function FlexGroup({ children, gutterSize = 'l', direction = 'row', style }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiFlexGroup, { gutterSize: gutterSize, direction: direction, style: style, children: children }));
}
exports.FlexGroup = FlexGroup;
