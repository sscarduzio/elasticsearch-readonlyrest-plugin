"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeaderSectionItemButton = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const eui_1 = require("@elastic/eui");
function HeaderSectionItemButton({ onClick, children, textProps }) {
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiHeaderSectionItemButton, { textProps: textProps, onClick: onClick, children: children }));
}
exports.HeaderSectionItemButton = HeaderSectionItemButton;
