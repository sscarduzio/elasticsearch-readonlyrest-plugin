"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Popover = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const react_1 = require("react");
const eui_1 = require("@elastic/eui");
function Popover({ children, style, id, isOpen, anchorPosition, closePopover, panelPaddingSize, repositionOnScroll = true, hasArrow, button, ownFocus = false }) {
    const emptyCloseAction = () => 'noop';
    const theme = sessionStorage.getItem('rorTheme');
    const backgroundColor = theme === 'dark' ? '#1E1D24' : '#fff';
    (0, react_1.useEffect)(() => {
        let observer;
        const panel = document.querySelector('.euiPopover__panel');
        if (panel) {
            observer = new MutationObserver(mutation => {
                const popover = mutation.find(element => 
                // @ts-ignore
                element.target.children[0]?.className?.includes('euiPopover__arrow'));
                if (popover) {
                    // @ts-ignore
                    const arrow = popover.target?.children?.[0];
                    const changePopoverArrowColor = () => {
                        if (theme === 'light') {
                            if (arrow.className.includes('euiPopoverArrow-left')) {
                                arrow.classList.add('euiPopover__arrow--left--light');
                            }
                            if (arrow.className.includes('euiPopoverArrow-bottom')) {
                                arrow.classList.add('euiPopover__arrow--bottom--light');
                            }
                        }
                        if (theme === 'dark') {
                            if (arrow.className.includes('euiPopoverArrow-left')) {
                                arrow.classList.add('euiPopover__arrow--left--dark');
                            }
                            if (arrow.className.includes('euiPopoverArrow-bottom')) {
                                arrow.classList.add('euiPopover__arrow--bottom--dark');
                            }
                        }
                    };
                    changePopoverArrowColor();
                }
            });
            observer.observe(panel, { attributes: true });
        }
        return () => observer?.disconnect?.();
    }, [theme]);
    return (
    // @ts-ignore
    (0, jsx_runtime_1.jsx)(eui_1.EuiPopover, { panelStyle: { backgroundColor }, button: button, 
        // @ts-ignore
        style: style, id: id, isOpen: isOpen, anchorPosition: anchorPosition, closePopover: closePopover || emptyCloseAction, panelPaddingSize: panelPaddingSize, repositionOnScroll: repositionOnScroll, hasArrow: hasArrow, ownFocus: ownFocus, children: children }));
}
exports.Popover = Popover;
