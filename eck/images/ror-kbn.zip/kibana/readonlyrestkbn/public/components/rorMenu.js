"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RorMenu = void 0;
const tslib_1 = require("tslib");
const jsx_runtime_1 = require("react/jsx-runtime");
/* Copyright (C) Beshu Limited t/a ReadonlyREST Security - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Beshu Limited <info@readonlyrest.com> in London, UK
 */
const React = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const headerSectionItemButton_1 = require("./common/headerSectionItemButton");
const spacer_1 = require("./common/spacer");
const button_1 = require("./common/button");
const flexGroup_1 = require("./common/flexGroup");
const flexItem_1 = require("./common/flexItem");
const infoApiResponse_1 = require("./infoApiResponse");
const tenancy_select_1 = tslib_1.__importDefault(require("./tenancy-select"));
const group_1 = tslib_1.__importDefault(require("./ror-menu/group"));
const paragraph_1 = tslib_1.__importDefault(require("./ror-menu/paragraph"));
const rorPopover_1 = require("./rorPopover");
const popoverTitle_1 = tslib_1.__importDefault(require("./common/popoverTitle"));
const coreFunctions_1 = tslib_1.__importDefault(require("../utils/coreFunctions"));
const actionsGroups_1 = tslib_1.__importDefault(require("./ror-menu/actionsGroups"));
const expiryDate_1 = tslib_1.__importDefault(require("./ror-menu/expiry/expiryDate"));
class RorMenu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showRorMenu: false,
            info: new infoApiResponse_1.InfoApiResponse(new infoApiResponse_1.Identity('', [], '', '', '', []), undefined, undefined, '')
        };
    }
    componentDidMount() {
        const { pkpBasePath } = this.props;
        console.log('Fetching system information...');
        fetch(`${pkpBasePath}/api/info`)
            .then(response => response.json())
            .then(json => {
            console.log(`>> Setting rorMenu state : ${JSON.stringify(json, null, 2)}`);
            return json;
        })
            .then((info) => {
            console.log('>> info ', info);
            this.setState({ info });
            this.handleTlExpiry();
        })
            .catch(e => console.log('Error fetching global info ', e));
        document.getElementById('kibana-body')?.addEventListener('click', this.onHideSettings);
        window.addEventListener('popstate', this.onHideSettings);
        window.addEventListener('message', this.onMessageFromIframe, false);
        RorMenu.setTheme();
        this.handleInitRedirect();
    }
    componentWillUnmount() {
        const kibanaBody = document.getElementById('kibana-body');
        if (kibanaBody) {
            kibanaBody.removeEventListener('click', this.onHideSettings);
        }
        window.removeEventListener('popstate', this.onHideSettings);
        window.removeEventListener('message', this.onMessageFromIframe, false);
    }
    isAccessUnrestricted = (identity) => {
        const { kibanaAccess } = identity;
        return kibanaAccess === 'unrestricted' || kibanaAccess === 'admin';
    };
    toggleRorMenu = () => {
        const { showRorMenu } = this.state;
        this.setState({
            showRorMenu: !showRorMenu
        });
    };
    closeRorMenu = () => {
        this.setState({
            showRorMenu: false
        });
    };
    onLogoutClick = () => {
        const { logoutRedirect } = this.props;
        const logoutUrl = new URL(window.location.origin + logoutRedirect);
        logoutUrl.searchParams.set('nextUrl', window.location.pathname + window.location.search + window.location.hash);
        window.location.href = logoutUrl.href;
    };
    onFinishImpersonation = async () => {
        const { pkpBasePath } = this.props;
        try {
            const response = await fetch(`${pkpBasePath}/api/finish-impersonation`, {
                method: 'POST'
            });
            if (response.status !== 204) {
                const jsonResponse = await response.json();
                throw new Error(jsonResponse.message);
            }
            sessionStorage.setItem('rorImpersonationFinished', 'true');
            RorMenu.refreshPage();
        }
        catch (e) {
            console.log('Error fetching finish impersonation ', e);
        }
    };
    handleInitRedirect() {
        if (sessionStorage.getItem('rorImpersonationFinished')) {
            this.onGoToSettingsPageClick('impersonate');
            sessionStorage.removeItem('rorImpersonationFinished');
        }
    }
    static refreshPage() {
        window.location.href = coreFunctions_1.default.serverBasePathPrepend('/');
    }
    onGoToSettingsPageClick = (initialTab = 'settings') => {
        const { pkpBasePath } = this.props;
        const iframe = document.createElement('iframe');
        iframe.src = `${pkpBasePath}/web?basePath=${coreFunctions_1.default.serverBasePath}/&initialTab=${initialTab}`;
        iframe.frameBorder = '0';
        iframe.id = 'readonlyrestIframe';
        iframe.style.position = 'relative';
        iframe.style.zIndex = '999';
        iframe.style.height = '100%';
        iframe.style.width = '100%';
        iframe.style.top = '0';
        iframe.style.backgroundColor = 'white';
        iframe.style.border = 'none';
        this.setState({
            settingsWindow: {
                iframe,
                previousOverflow: document.body.style.overflow
            }
        });
        document.body.prepend(iframe);
        document.body.style.overflow = 'hidden';
        this.setState({
            showRorMenu: false
        });
    };
    onMessageFromIframe = event => {
        const { settingsWindow } = this.state;
        if (event.origin !== window.location.origin)
            return;
        const { data } = event;
        if (data?.settingsIframe === 'CLOSE') {
            this.onHideSettings();
            return;
        }
        if (data?.settingsIframe === 'REMOVE' && settingsWindow) {
            document.body.removeChild(settingsWindow.iframe);
            document.body.style.overflow = settingsWindow.previousOverflow;
            this.setState({ settingsWindow: undefined });
        }
        if (data?.settingsIframe === 'REFRESH_PAGE') {
            RorMenu.refreshPage();
        }
    };
    onHideSettings = () => {
        const { settingsWindow } = this.state;
        if (settingsWindow) {
            const iframeElement = document.getElementById('readonlyrestIframe');
            iframeElement.contentWindow?.postMessage({ settingsIframe: 'CLOSE_EVENT_DISPATCHED' }, '*');
        }
    };
    getBadgeLabel = () => {
        const { info } = this.state;
        switch (info.identity.kibanaAccess) {
            case 'ro':
                return 'ro';
            case 'ro_strict':
                return 'rs';
            case 'rw':
                return 'rw';
            case 'admin':
                return 'a';
            case 'unrestricted':
                return 'u';
            default:
                return '';
        }
    };
    renderAccessLevel = () => {
        const { info } = this.state;
        const identity = info.identity;
        return this.isAccessUnrestricted(identity)
            ? identity.kibanaAccess
            : identity.kibanaAccess && identity.kibanaAccess.toUpperCase();
    };
    onTenancyHop = (value) => {
        const { clearSessionOnEvents } = this.props;
        if (clearSessionOnEvents?.includes('tenancyHop')) {
            window.localStorage?.clear();
            window.localStorage.setItem(`insecureClusterWarningVisibility${coreFunctions_1.default.serverBasePath}`, '{ "show": false}');
            window.sessionStorage?.clear();
        }
        window.location.href = coreFunctions_1.default.serverBasePathPrepend(`/switch-group?group=${encodeURIComponent(value)}&redirectTo=${encodeURIComponent(window.location.href)}`);
    };
    getExpiresIn = () => {
        function daysUntilNow(epochSeconds) {
            const A_DAY_IN_MILLISECONDS = 1000 * 60 * 60 * 24;
            const now = new Date();
            const expirationDate = new Date(epochSeconds * 1000);
            const diff = expirationDate.getTime() - now.getTime();
            return Math.ceil(diff / A_DAY_IN_MILLISECONDS);
        }
        const { info } = this.state;
        // epoch to days until expiry
        return daysUntilNow(info.licenseInfo?.exp ?? -1);
    };
    static setTheme() {
        const isDarkMode = coreFunctions_1.default.getSettingsParameter('theme:darkMode');
        sessionStorage.setItem('rorTheme', isDarkMode ? 'dark' : 'light');
    }
    handleTlExpiry() {
        const { info } = this.state;
        const validTo = localStorage.getItem('rorTtlValidTo');
        if (validTo && info.identity.impersonatedBy) {
            const expirationTime = new Date(validTo).getTime() - Date.now();
            const timeout = setTimeout(async () => {
                await this.onFinishImpersonation();
                clearTimeout(timeout);
            }, expirationTime);
        }
    }
    getVersionString() {
        const { info } = this.state;
        const versionString = `${info.distribution?.rorVersion}_es${info.distribution?.kibanaVersion}`;
        return `${info.licenseInfo?.license.edition_name} ${versionString} 🦄`;
    }
    showActivationKeys = () => {
        const { info } = this.state;
        const identity = info.identity;
        return !(identity.kibanaHiddenApps.includes('readonlyrest_kbn') ||
            identity.kibanaHiddenApps.includes('ROR Security Settings'));
    };
    licenseBadgeColor() {
        // eslint-disable-next-line react/destructuring-assignment
        const edition = this.state.info.licenseInfo?.license.edition;
        if (edition === 'kbn_free') {
            // Free does not expire
            return 'success';
        }
        const days2Expiry = this.getExpiresIn();
        if (days2Expiry < 30) {
            return 'danger';
        }
        return 'primary';
    }
    licenseBadgeIcon() {
        const days2Expiry = this.getExpiresIn();
        if (days2Expiry < 30) {
            return 'alert';
        }
        // eslint-disable-next-line react/destructuring-assignment
        return this.state.info.licenseInfo?.license.edition === 'kbn_free' ? 'pencil' : 'check';
    }
    onLabelBadgeOnClick() {
        if (this.showActivationKeys()) {
            this.onGoToSettingsPageClick('activation_keys');
        }
    }
    licenseBadgeText() {
        const { info } = this.state;
        const days2Expiry = this.getExpiresIn();
        let daysText = '';
        if (days2Expiry < 30) {
            daysText = ` (${days2Expiry} days left!)`;
        }
        return (info.licenseInfo?.license.edition_name ?? 'UNKNOWN') + daysText;
    }
    licenseTooltipText() {
        const { info } = this.state;
        return info.licenseInfo?.license.edition === 'kbn_free' ? 'Add activation key' : 'Edit activation key';
    }
    render() {
        const { info, showRorMenu } = this.state;
        const { identity, distribution, licenseInfo } = info;
        console.log('Rendering, licenseInfo', licenseInfo);
        const { pkpBasePath } = this.props;
        const validTo = localStorage.getItem('rorTtlValidTo');
        const button = ((0, jsx_runtime_1.jsx)(headerSectionItemButton_1.HeaderSectionItemButton, { onClick: this.toggleRorMenu, textProps: {
                style: { display: 'flex', justifyContent: 'center', alignItems: 'center' }
            }, children: (0, jsx_runtime_1.jsx)("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'center' }, children: (0, jsx_runtime_1.jsx)("img", { alt: "ReadonlyREST", height: "20", src: `${pkpBasePath}/legacy/web/assets/rorSVG.svg` }) }) }));
        return ((0, jsx_runtime_1.jsxs)(rorPopover_1.RorPopover, { id: "rorMenuPopover", button: button, isOpen: showRorMenu, closePopover: this.closeRorMenu, anchorPosition: "downCenter", panelPaddingSize: "m", badgeLabel: this.getBadgeLabel(), badgeTitle: identity.kibanaAccess, children: [(0, jsx_runtime_1.jsxs)(popoverTitle_1.default, { children: [(0, jsx_runtime_1.jsxs)(flexGroup_1.FlexGroup, { children: [(0, jsx_runtime_1.jsx)(flexItem_1.FlexItem, { style: { whiteSpace: 'nowrap' }, children: "ReadonlyREST" }), (0, jsx_runtime_1.jsx)(flexItem_1.FlexItem, { style: { alignItems: 'end', marginTop: '15px' }, children: (0, jsx_runtime_1.jsx)(eui_1.EuiToolTip, { content: this.licenseTooltipText(), children: (0, jsx_runtime_1.jsx)(eui_1.EuiBadge, { onClick: () => this.onLabelBadgeOnClick(), iconOnClick: () => this.onLabelBadgeOnClick(), iconOnClickAriaLabel: "", style: { width: 'fit-content' }, color: this.licenseBadgeColor(), iconType: this.licenseBadgeIcon(), onClickAriaLabel: "", children: this.licenseBadgeText() }) }) })] }), (0, jsx_runtime_1.jsx)(flexGroup_1.FlexGroup, { children: (0, jsx_runtime_1.jsx)(flexItem_1.FlexItem, { className: "chrHeaderHelpMenu__version", style: {
                                    fontWeight: 200,
                                    fontSize: '85%',
                                    whiteSpace: 'nowrap',
                                    marginBottom: '6px'
                                }, children: this.getVersionString() }) })] }), (0, jsx_runtime_1.jsx)(actionsGroups_1.default, { identity: identity, closeRorMenu: this.closeRorMenu, isAccessUnrestricted: this.isAccessUnrestricted(identity), handleSettingsPageClick: page => this.onGoToSettingsPageClick(page), kibanaVersion: distribution?.kibanaVersion || '??' }), (identity.availableGroups ?? []).length > 0 && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)(group_1.default, { label: "Tenancies", children: [(0, jsx_runtime_1.jsx)(paragraph_1.default, { label: "Currently on:", value: identity.currentGroup ?? '' }), (0, jsx_runtime_1.jsx)(tenancy_select_1.default, { availableGroups: identity.availableGroups ?? [], handleChange: this.onTenancyHop, currentGroup: identity.currentGroup ?? '', closeMainMenu: this.closeRorMenu })] }), (0, jsx_runtime_1.jsx)(spacer_1.Spacer, {})] })), (0, jsx_runtime_1.jsxs)(group_1.default, { label: "Identity", children: [identity.impersonatedBy ? ((0, jsx_runtime_1.jsx)(paragraph_1.default, { "data-testid": "identity-impersonating", label: "Impersonating:", value: identity.username })) : ((0, jsx_runtime_1.jsx)(paragraph_1.default, { "data-testid": "identity-logged-in-as", label: "Logged in as:", value: identity.username })), identity.kibanaAccess && ((0, jsx_runtime_1.jsx)(paragraph_1.default, { "data-testid": "identity-access", label: "Access level:", value: this.renderAccessLevel() ?? '' })), (0, jsx_runtime_1.jsx)(button_1.Button, { onClick: this.onLogoutClick, color: "danger", fullWidth: true, children: "Log out" }), identity.impersonatedBy && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(spacer_1.Spacer, { size: "m" }), (0, jsx_runtime_1.jsx)(button_1.Button, { onClick: this.onFinishImpersonation, color: 'secondary', fullWidth: true, children: "Finish impersonation" }), validTo && ((0, jsx_runtime_1.jsx)(paragraph_1.default, { style: {
                                        marginTop: '8px',
                                        display: 'flex',
                                        justifyContent: 'center'
                                    }, "data-testid": "automatically-deactivate", label: "Deactivated in:", value: (0, jsx_runtime_1.jsx)(expiryDate_1.default, { validTo: validTo }) }))] }))] })] }));
    }
}
exports.RorMenu = RorMenu;
