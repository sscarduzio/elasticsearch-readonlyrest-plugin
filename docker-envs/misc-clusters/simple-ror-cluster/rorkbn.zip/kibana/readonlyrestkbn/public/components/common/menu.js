"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsx_runtime_1 = require("react/jsx-runtime");
const popover_1 = require("./popover");
const flexGroup_1 = require("./flexGroup");
const linkButton_1 = __importDefault(require("./linkButton"));
const text_1 = require("./text");
const search_1 = __importDefault(require("./search"));
const spacer_1 = require("./spacer");
function Menu({ button, isOpen, handleClose, closeMainMenu, items, selectedItem, search }) {
    const getGroupStyle = () => {
        const style = { overflow: 'auto', maxHeight: '250px' };
        if (search) {
            style.minHeight = '250px';
            style.width = '234px';
        }
        return style;
    };
    return ((0, jsx_runtime_1.jsxs)(popover_1.Popover, { button: button, closePopover: handleClose, style: { display: 'grid' }, id: "rorKibanaManagementPopover", isOpen: isOpen, anchorPosition: "leftDown", panelPaddingSize: "s", hasArrow: false, children: [search && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)(search_1.default, { value: search.value, placeholder: search.placeholder, onChange: search.onChange, isClearable: search.isClearable, style: { width: '234px' }, autoFocus: true }), (0, jsx_runtime_1.jsx)(spacer_1.Spacer, { size: "m" })] })), (0, jsx_runtime_1.jsx)(flexGroup_1.FlexGroup, { direction: "column", gutterSize: "s", style: getGroupStyle(), children: items.map((menuItem, index) => ((0, jsx_runtime_1.jsx)(linkButton_1.default, { style: { color: 'inherit' }, isSelected: selectedItem === menuItem.title, onClick: event => {
                        menuItem.action(event);
                        if (closeMainMenu) {
                            handleClose();
                            closeMainMenu();
                        }
                    }, children: (0, jsx_runtime_1.jsx)(text_1.Text, { style: { whiteSpace: 'normal', wordBreak: 'break-word', textAlign: 'right' }, children: menuItem.title }) }, index))) })] }));
}
exports.default = Menu;
